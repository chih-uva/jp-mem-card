function startLearning() {
  window.location.href = './start.html'; // Redirect to start learning page
}

function goToConfig() {
  window.location.href = 'config.html'; // Redirect to config page
}

function addVocabulary() {
  window.location.href = 'add.html'; // Redirect to add vocabulary page
}

function selectDate() {
  window.location.href = 'select.html'; // Redirect to select date page
}
